CREATE DATABASE trading_system;
USE trading_system;
CREATE TABLE orders (
  order_id VARCHAR(50) PRIMARY KEY,
  cl_ord_id VARCHAR(50),
  symbol VARCHAR(20),
  side CHAR(1),
  price DECIMAL(15,2),
  quantity DECIMAL(15,0),
  status VARCHAR(20),
  timestamp TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);
SELECT * FROM orders ORDER BY order_id DESC;
INSERT INTO orders (order_id, cl_ord_id, symbol, side, price, quantity, status)
VALUES ('manual_test', 'manual_test', 'GOOG', '1', 150, 100, 'NEW');
SET SQL_SAFE_UPDATES = 0;
SET SQL_SAFE_UPDATES = 0;

DELETE FROM executions;
DELETE FROM orders;

SET SQL_SAFE_UPDATES = 1;

CREATE TABLE security_master (
 symbol VARCHAR(20) PRIMARY KEY,
 security_type VARCHAR(20),
 description VARCHAR(100),
 underlying VARCHAR(20),
 lot_size INT DEFAULT 100
);

CREATE TABLE customer_master (
 customer_code VARCHAR(20) PRIMARY KEY,
 customer_name VARCHAR(100),
 customer_type VARCHAR(20),
 credit_limit DECIMAL(20, 2)
);

CREATE TABLE executions (
 exec_id VARCHAR(50) PRIMARY KEY,
 order_id VARCHAR(50),
 symbol VARCHAR(20),
 side CHAR(1),
 exec_qty INT,
 exec_price DECIMAL(15, 2),
 match_time TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
 CONSTRAINT fk_order FOREIGN KEY (order_id) REFERENCES orders(order_id)
);

INSERT INTO security_master (symbol, security_type, lot_size) VALUES
('GOOG', 'CS', 1),
('MSFT', 'CS', 1),
('IBM', 'CS', 1);
ALTER TABLE executions
ADD CONSTRAINT fk_order
FOREIGN KEY (order_id)
REFERENCES orders(order_id);
select*from orders;
SHOW CREATE TABLE executions;

INSERT INTO security_master (symbol, security_type, lot_size) VALUES
('GOOG', 'CS', 1),
('MSFT', 'CS', 1),
('IBM', 'CS', 1);